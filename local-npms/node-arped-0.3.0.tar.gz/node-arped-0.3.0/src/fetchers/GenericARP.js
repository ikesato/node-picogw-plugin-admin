import ARP from './ARP';

export default class GenericARP extends ARP {
    constructor() {
        super();
    }
}
