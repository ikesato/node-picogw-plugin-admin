export default class ARP {
    constructor() {}

    fetch() {
        throw new Error('Not Implemented');
    }
}
