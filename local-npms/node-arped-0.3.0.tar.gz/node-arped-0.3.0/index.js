module.exports = (function () {
    var Arped = require('./lib/index').default;

    return new Arped();
})();
